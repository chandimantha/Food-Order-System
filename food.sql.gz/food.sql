-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2021 at 02:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(17, 'octopus', 'octopus', 'fcf1eed8596699624167416a1e7e122e'),
(18, 'chandi', 'chandi', '035ca0f612d3e4f0b9e80cd0869461d7');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(7, 'Burger', 'Food_Category_918.jfif', 'Yes', 'Yes'),
(10, 'Pizza', 'Food_Category_780.jpg', 'Yes', 'Yes'),
(12, 'Biriyani', 'Food_Category_170.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(7, 'Burger with chips', 'Beef With Chilli Sauce', '38.00', 'Food-Name-7130.jfif', 7, 'Yes', 'Yes'),
(8, 'Chicken Pizza', 'Barbque chiken', '23.00', 'Food-Name-4043.jfif', 10, 'Yes', 'Yes'),
(12, 'Pepperoni Pizza', 'Delicious', '34.00', 'Food-Name-5355.jfif', 10, 'Yes', 'Yes'),
(13, 'Wild Salmon Burgers', 'healthy burger alternative, serve up delicious', '22.00', 'Food-Name-8397.jpg', 7, 'Yes', 'Yes'),
(19, 'Beef Biriyani', ' using two pounds of beef stew pieces', '37.00', 'Food-Name-5262.jpg', 12, 'Yes', 'Yes'),
(22, 'Chicken Biriyani', 'chicken, rice, and aromatics that are steamed together.', '20.00', 'Food-Name-1714.jpg', 12, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(1, 'Plate', '14.00', 4, '56.00', '2021-01-08 04:47:31', 'Delivered', 'chan', '32154654654', 'chandimantha1234@yahoo.com', 'gdjj'),
(2, 'Plate', '14.00', 3, '3.00', '2021-01-08 05:12:38', 'Cancelled', 'chan', '32154654654', 'chandimantha1234@yahoo.com', 'fhsdhhhd'),
(3, 'Food', '67.00', 3, '201.00', '2021-01-08 06:21:45', 'Delivered', 'chan', '32154654654', 'chandimantha1234@yahoo.com', 'fgsh'),
(4, 'Plate', '14.00', 10, '10.00', '2021-01-08 06:30:44', 'On Delivery', 'chan', '32154654654', 'chandimantha1234@yahoo.com', 'fdhhsjfj'),
(5, 'Burger with chips', '38.00', 3, '114.00', '2021-01-09 02:52:04', 'Delivered', 'Rashika', '+94 775632147', 'rasika34@gmail.com', 'No.45/1, Chikago'),
(6, 'Chicken Pizza', '23.00', 3, '69.00', '2021-01-10 02:14:27', 'Ordered', 'chan', '+94 775632147', 'chandimantha97200@gmail.com', 'gjdjjgj'),
(7, 'Burger with chips', '38.00', 2, '76.00', '2021-01-18 02:26:37', 'Cancelled', 'wijesuriyaaa', '25985632', 'chandimantha1234@yahoo.com', 'kuru');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
